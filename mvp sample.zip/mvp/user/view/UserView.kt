package m.com.mvp.user.view

import m.com.gitresume.data.GitUser

/**
 * Created by M1033070 on 2/26/2019.
 */
interface UserView {
    fun loadProgress(boolean: Boolean)
    fun onSuccess(user: GitUser)
    fun onFailure(error: Throwable)
}