package m.com.mvp.user.presenter

/**
 * Created by M1033070 on 2/26/2019.
 */
interface UserPresenter{
    fun loadUsers(userName:String)
    fun onDestroy()
}