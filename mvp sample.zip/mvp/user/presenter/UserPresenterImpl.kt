package m.com.mvp.user.presenter

import m.com.gitresume.data.GitUser
import m.com.mvp.user.interactor.UserInteractor
import m.com.mvp.user.view.UserView

/**
 * Created by M1033070 on 2/26/2019.
 */
class UserPresenterImpl(
        private var mView: UserView?,
        private val mInteractor: UserInteractor
    ) : UserInteractor.OnFinishedListener, UserPresenter {

    override fun loadUsers(userName: String) {
        mView?.loadProgress(true)
        mInteractor.requestGetUser(this,userName)
    }

    override fun onResultSuccess(users: GitUser) {
        mView?.loadProgress(false)
        mView?.onSuccess(users)
    }

    override fun onResultFail(error: Throwable) {
        mView?.loadProgress(false)
        mView?.onFailure(error)
    }

    override fun onDestroy(){
        mView = null
    }
}