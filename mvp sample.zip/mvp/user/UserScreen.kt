package m.com.mvp.user

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.util.Log
import kotlinx.android.synthetic.main.activity_home.*
import m.com.gitresume.R
import m.com.gitresume.data.GitUser
import m.com.mvp.user.interactor.UserInteractor
import m.com.mvp.user.presenter.UserPresenter
import m.com.mvp.user.presenter.UserPresenterImpl
import m.com.mvp.user.view.UserView

class UserScreen : AppCompatActivity(),UserView {

    // Initialize Presenter (also Model in the constructor of Presenter) & has object of Presenter
    private lateinit var uPresenter: UserPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_screen)
        uPresenter = UserPresenterImpl(this,UserInteractor())
        btnNext.setOnClickListener{uPresenter.loadUsers("mxcl") }
    }

    override fun loadProgress(status: Boolean) {
       if(status){
           Log.i("UserScreen","Loading.. start...")
       }
        else {
           Log.i("UserScreen","Loading.. stop...")
       }
    }

    override fun onSuccess(user: GitUser) {
        Log.i("UserScreen",user.name)
    }

    override fun onFailure(error: Throwable) {
        Log.i("UserScreen",error.message)

    }

}
