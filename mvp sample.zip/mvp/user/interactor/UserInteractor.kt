package m.com.mvp.user.interactor

import android.util.Log
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import m.com.gitresume.api.RequestInterface
import m.com.gitresume.data.GitUser

/**
 * Created by M1033070 on 2/26/2019.
 */
class UserInteractor {


    interface OnFinishedListener {
        fun onResultSuccess(users: GitUser)
        fun onResultFail(strError: Throwable)
    }

    fun requestGetUser(onFinishedListener: OnFinishedListener,userName:String) {
        Log.i("inside", "requestGetUser")
        var disposable: Disposable? = null
        val client by lazy {
            RequestInterface.create()
        }
        disposable = client.getData("mxcl")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        {
                            onFinishedListener.onResultSuccess(it)
                        },
                        {
                            onFinishedListener.onResultFail(it)
                           // error -> Log.i("ERROR", error.message)
                        }
                )
    }
}